<?php

namespace PragmaRX\Tracker\Support;

use Illuminate\Filesystem\Filesystem as IlluminateFilesystem;

class Filesystem extends IlluminateFilesystem
{
}
