<?php

namespace PragmaRX\Tracker\Support\Exceptions;

use Exception;

class UserDeprecated extends Exception
{
}
