<?php

namespace PragmaRX\Tracker\Support\Exceptions;

use Exception;

class UserNotice extends Exception
{
}
