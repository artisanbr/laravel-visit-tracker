<?php

namespace PragmaRX\Tracker\Support\Exceptions;

use Exception;

class CompileError extends Exception
{
}
