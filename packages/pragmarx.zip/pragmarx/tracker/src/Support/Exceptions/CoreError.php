<?php

namespace PragmaRX\Tracker\Support\Exceptions;

use Exception;

class CoreError extends Exception
{
}
