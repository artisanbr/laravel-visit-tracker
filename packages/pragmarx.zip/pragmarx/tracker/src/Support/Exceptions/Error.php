<?php

namespace PragmaRX\Tracker\Support\Exceptions;

use ErrorException;

class Error extends ErrorException
{
}
