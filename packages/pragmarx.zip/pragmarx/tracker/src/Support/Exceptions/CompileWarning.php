<?php

namespace PragmaRX\Tracker\Support\Exceptions;

use Exception;

class CompileWarning extends Exception
{
}
