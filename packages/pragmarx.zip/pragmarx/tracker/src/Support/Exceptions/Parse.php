<?php

namespace PragmaRX\Tracker\Support\Exceptions;

use Exception;

class Parse extends Exception
{
}
