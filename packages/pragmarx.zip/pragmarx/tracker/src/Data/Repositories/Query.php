<?php

namespace PragmaRX\Tracker\Data\Repositories;

class Query extends Repository
{
}
