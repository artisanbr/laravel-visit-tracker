<?php

namespace PragmaRX\Tracker\Data\Repositories;

class SqlQueryLog extends Repository
{
}
