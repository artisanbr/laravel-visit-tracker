<?php

namespace PragmaRX\Tracker\Data\Repositories;

class RoutePath extends Repository
{
}
