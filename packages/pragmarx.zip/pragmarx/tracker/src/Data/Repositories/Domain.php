<?php

namespace PragmaRX\Tracker\Data\Repositories;

class Domain extends Repository
{
}
