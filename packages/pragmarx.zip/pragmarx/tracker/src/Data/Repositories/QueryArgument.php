<?php

namespace PragmaRX\Tracker\Data\Repositories;

class QueryArgument extends Repository
{
}
