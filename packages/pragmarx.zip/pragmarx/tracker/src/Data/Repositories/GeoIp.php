<?php

namespace PragmaRX\Tracker\Data\Repositories;

class GeoIp extends Repository
{
}
