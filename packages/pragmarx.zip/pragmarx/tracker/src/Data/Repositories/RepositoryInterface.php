<?php

namespace PragmaRX\Tracker\Data\Repositories;

interface RepositoryInterface
{
}
