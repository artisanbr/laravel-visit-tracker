<?php

namespace PragmaRX\Tracker\Data\Repositories;

class User extends Repository
{
}
