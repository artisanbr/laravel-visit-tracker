<?php

namespace PragmaRX\Tracker\Data\Repositories;

class Path extends Repository
{
}
