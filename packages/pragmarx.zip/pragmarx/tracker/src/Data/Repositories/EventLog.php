<?php

namespace PragmaRX\Tracker\Data\Repositories;

class EventLog extends Repository
{
}
