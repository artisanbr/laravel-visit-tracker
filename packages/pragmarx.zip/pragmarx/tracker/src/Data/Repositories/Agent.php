<?php

namespace PragmaRX\Tracker\Data\Repositories;

class Agent extends Repository
{
}
