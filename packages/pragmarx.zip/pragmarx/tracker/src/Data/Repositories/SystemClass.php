<?php

namespace PragmaRX\Tracker\Data\Repositories;

class SystemClass extends Repository
{
}
