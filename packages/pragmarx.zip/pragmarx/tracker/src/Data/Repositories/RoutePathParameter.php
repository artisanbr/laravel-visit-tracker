<?php

namespace PragmaRX\Tracker\Data\Repositories;

class RoutePathParameter extends Repository
{
}
