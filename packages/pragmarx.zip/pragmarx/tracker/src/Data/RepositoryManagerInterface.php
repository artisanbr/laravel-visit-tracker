<?php

namespace PragmaRX\Tracker\Data;

interface RepositoryManagerInterface
{
}
