<?php
 
namespace PragmaRX\Support\Exceptions;

class EnvironmentVariableNotSet extends Exception {

}
