<?php
 
namespace PragmaRX\Support;

use Illuminate\Filesystem\Filesystem as IlluminateFilesystem;

class Filesystem extends IlluminateFilesystem {

}
